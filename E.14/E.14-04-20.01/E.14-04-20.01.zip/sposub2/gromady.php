<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style12.css">
    <title>Gromady kręgowców</title>
</head>
<body>
    <div id="menu">
        <a href="gromada-ryby.php">gromada ryb</a>
        <a href="gromada-ptaki.php">gromada ptaków</a>
        <a href="gromada-ssaki.php">gromada ssaków</a>
        <a href="gromady.php">gromada kręgowców</a>
    </div>
    <div id="logo">
        <h2>GROMADY KRĘGOWCÓW</h2>
    </div>
    <div id="glownyL">
        <!--scrypt1-->
        <?php
            $conn = mysqli_connect('localhost','root','','egzamin5');
            $qr='select id, Gromady_id, gatunek, wystepowanie from zwierzeta where Gromady_id = 5 || Gromady_id = 4';
            $result = $conn->query($qr);
            while($r = $result->fetch_array())  
            {
                if($r[1]==4)
                {
                    $gromada = "ptaki";
                }
                else if($r[1]==5)
                {
                    $gromada = "ssaki";
                }
                echo "<p>".$r[0]. ".".$r[2]."</p><p>Występowanie: ".$r[2].", gromada ".$r[1]." ,".$gromada."</p><hr>";
            }
        ?>
    </div>
    <div id="glownyP">
        <h1>KRĘGOWCE</h1>
        <ol>
            <!--scrypt2-->
            <?php
                $qr='SELECT gatunek , obraz from zwierzeta where gromady_id = 4 || Gromady_id = 5';
                $result = $conn->query($qr);
                while ($r = $result -> fetch_array())
                {
                    echo "<a href='$r[1]' target='_blank'><li>$r[0]</li></a>";
                }
                mysqli_close($conn);
            ?>
        </ol>
        <img src="hiena.jpg" alt="Sroka zwyczajna, gromada ptaki">  
    </div>
    <div id="stopka">
        Stronę o kręgowcach przygotował: 1234567890
    </div>
</body>
</html>
<?php
    $conn=mysqli_connect("localhost","root","","dane3");
?>